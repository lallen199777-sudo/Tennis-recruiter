# Recruiting Board

A junior tennis recruiting tracker: outreach pipeline, reach/target/likely
fit against your UTR, application deadlines, and a 267-school reference
directory (D1/D2/D3/NAIA).

**Data storage:** everything is saved in your browser's local storage.
There's no login and no server — your board only exists on the device
and browser you use it in. Clearing your browser data will erase it, so
don't rely on this as a permanent backup.

## Running it locally (to test before deploying)

You'll need [Node.js](https://nodejs.org) installed (any recent version).

```bash
npm install
npm run dev
```

Then open the URL it prints (usually `http://localhost:5173`).

## Putting it on the actual internet — free, ~10 minutes

The easiest path is **Vercel**:

1. Go to [vercel.com](https://vercel.com) and sign up (free) — you can use
   a GitHub account or an email.
2. Put this project's files somewhere Vercel can see them. Two ways:
   - **Easiest, no coding tools needed:** create a free
     [GitHub](https://github.com) account, make a new repository, and
     upload all these files to it through GitHub's website (there's an
     "upload files" button — drag the whole folder in).
   - **If you're comfortable with git:** `git init`, commit these files,
     push to a new GitHub repo.
3. In Vercel, click "Add New Project," pick the GitHub repo you just
   made, and click Deploy. Vercel automatically detects it's a Vite
   project and builds it correctly — you shouldn't need to change any
   settings.
4. After a minute or two, Vercel gives you a live URL
   (something like `recruiting-board.vercel.app`) that anyone can visit.

Netlify works almost identically if you'd rather use that instead.

## A limitation worth knowing

Because data lives in browser local storage, **each visitor gets their
own separate, empty board** — there's no shared login, and you can't see
someone else's data or vice versa. If you want real accounts that sync
across devices, that's a bigger step (a database and login system), not
something this version does.
