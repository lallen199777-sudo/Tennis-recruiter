// Local storage adapter — mirrors the shape of the Claude artifact
// window.storage API (get/set returning { key, value } or null) so the
// rest of the app didn't need to change. Data lives only in this browser;
// there is no account system and nothing is sent to a server.

export const storage = {
  async get(key) {
    try {
      const value = window.localStorage.getItem(key);
      if (value === null) return null;
      return { key, value };
    } catch (e) {
      return null;
    }
  },
  async set(key, value) {
    try {
      window.localStorage.setItem(key, value);
      return { key, value };
    } catch (e) {
      return null;
    }
  },
};
